const express = require('express');
const app = express();
const bodyParser = require('body-parser');

const getProvincesMW = require('/middlewares/provinces/getProvincesMW')
const renderMW = require('/middlewares/renderMW')
const searchProvincesMW = require('/middlewares/Provinces/searchProvincesMW')
const getProvinceMW = require('/middlewares/Provinces/getProvinceMW')
const saveProvinceMW = require('/middlewares/Provinces/saveProvinceMW')
const deleteProvinceMW = require('middlewares/Provinces/deleteProvinceMW')
const getGovernorsMW = require('/middlewares/Governors/getGovernorsMW')
const searchGovernorsMW = require('/middlewares/Governors/searchGovernorsMW')
const getGovernorMW = require('/middlewares/Governors/getGovernorMW')
const saveGovernorMW = require('/middlewares/Governors/saveGovernorMW')
const deleteGovernorMW = require('/middlewares/Governors/deleteGovernorMW')

module.exports = function(app) {
    const objRepo = { };

    app.use('/provinces',
        getProvincesMW(objRepo),
        renderMW(objRepo, 'provinces'));

    app.use('/provinces/?search=:searchterm',
        searchProvincesMW(objRepo),
        renderMW(objRepo, 'provinces'));

    app.use('/provinces/edit/:id',
        getProvinceMW(objRepo),
        saveProvinceMW(objRepo),
        renderMW(objRepo, 'provinces/edit'));
		
	app.get('/provinces/del/:id',
        getProvinceMW(objRepo),
		deleteProvinceMW(objRepo));
		
	app.use('/provinces/new',
        saveProvinceMW(objRepo));
		
		
		
		
		
	app.use('/governors',
        getGovernorsMW(objRepo),
        renderMW(objRepo, 'governors'));

    app.use('/governors/?search=:searchterm',
        searchGovernorsMW(objRepo),
        renderMW(objRepo, 'governors'));

    app.use('/governors/edit/:id',
        getGovernorMW(objRepo),
        saveGovernorMW(objRepo),
        renderMW(objRepo, 'governors/edit'));
		
	app.get('/governors/del/:id',
        getGovernorMW(objRepo),
		deleteGovernorMW(objRepo));
		
	app.use('/governors/new',
        saveGovernorMW(objRepo));
}




/*
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/provinces/list/provinces.html');
});

app.listen(3000, () => {
   console.log("Listening on port 3000");
});*/