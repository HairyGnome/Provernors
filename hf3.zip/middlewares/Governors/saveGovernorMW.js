/**
 * Saves a single governor to database
 */
module.exports = function(objectrepostiory) {
    return function(req, res, next) {
        return next();
    };
};