/**
 * Saves a single province to database
 */
module.exports = function(objectrepostiory) {
    return function(req, res, next) {
        return next();
    };
};