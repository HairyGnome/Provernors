/**
 * Load all provinces that match searchterm from database
 */
module.exports = function(objectrepostiory) {
    return function(req, res, next) {
        return next();
    };
};