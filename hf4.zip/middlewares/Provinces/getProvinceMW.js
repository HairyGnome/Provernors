/**
 * Gets single province from database by id
 */
module.exports = function(objectrepostiory) {
    return function(req, res, next) {
        return next();
    };
};