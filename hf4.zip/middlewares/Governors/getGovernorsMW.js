/**
 * Load all governors from database
 */
module.exports = function(objectrepostiory) {
    return function(req, res, next) {
        return next();
    };
};